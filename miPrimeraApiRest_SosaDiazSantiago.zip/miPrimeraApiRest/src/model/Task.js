export class Task{
    constructor(id,texto,fechaRecordatorio){
        this.id=id;
        this.texto=texto;
        this.fechaRecordatorio=fechaRecordatorio;
    }
}